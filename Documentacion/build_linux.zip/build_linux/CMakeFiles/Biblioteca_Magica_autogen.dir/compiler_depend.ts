# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for Biblioteca_Magica_autogen.
